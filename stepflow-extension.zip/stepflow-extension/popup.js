/* ============================================================
   yipengPPT  –  Popup Script
   控制弹出窗口的交互：录制控制、步骤展示、导出 PPT
   ============================================================ */

const $ = (sel) => document.querySelector(sel);

const viewIdle      = $('#viewIdle');
const viewRecording = $('#viewRecording');
const viewSteps     = $('#viewSteps');
const viewExport    = $('#viewExport');

const statusDot     = $('#statusDot');
const statusText    = $('#statusText');
const timerEl       = $('#timer');

const titleInput    = $('#titleInput');
const btnStart      = $('#btnStart');
const btnStop       = $('#btnStop');
const recCount      = $('#recCount');

const stepsTitle    = $('#stepsTitle');
const stepsCount    = $('#stepsCount');
const stepsList     = $('#stepsList');
const emptyState    = $('#emptyState');

const btnExportPPT    = $('#btnExportPPT');
const btnNewRecording = $('#btnNewRecording');

const exportOverlay = $('#exportOverlay');
const exportStatus  = $('#exportStatus');

let timerInterval    = null;
let keepaliveInterval = null;

// ── 初始化 ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await refreshStatus();

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'step-updated') {
      refreshStatus();
    }
  });

  // Popup 打开期间持续 ping background，防止 SW 被杀
  keepaliveInterval = setInterval(() => {
    chrome.runtime.sendMessage({ action: 'ping' }, () => {
      if (chrome.runtime.lastError) {}
    });
  }, 20000);
});

// ── 按钮事件 ──────────────────────────────────────────────────
btnStart.addEventListener('click', async () => {
  const title = titleInput.value.trim() || '未命名流程';
  const resp = await sendBg({ action: 'start-recording', title });
  if (resp?.success) {
    switchView('recording');
    startTimer();
    setTimeout(() => window.close(), 300);
  }
});

btnStop.addEventListener('click', async () => {
  const resp = await sendBg({ action: 'stop-recording' });
  if (resp?.success) {
    stopTimer();
    await showStepsView(resp.steps);
  }
});

btnExportPPT.addEventListener('click', exportPPT);

btnNewRecording.addEventListener('click', async () => {
  await sendBg({ action: 'clear-steps' });
  switchView('idle');
  titleInput.value = '';
  titleInput.focus();
});

// ── 视图切换 ──────────────────────────────────────────────────
function switchView(name) {
  viewIdle.classList.toggle('hidden', name !== 'idle');
  viewRecording.classList.toggle('hidden', name !== 'recording');
  viewSteps.classList.toggle('hidden', name !== 'steps');
  viewExport.classList.toggle('hidden', name !== 'steps');

  if (name === 'recording') {
    statusDot.className = 'status-dot recording';
    statusText.textContent = '录制中';
  } else if (name === 'steps') {
    statusDot.className = 'status-dot stopped';
    statusText.textContent = '录制完成';
  } else {
    statusDot.className = 'status-dot idle';
    statusText.textContent = '未录制';
    timerEl.textContent = '';
  }
}

// ── 刷新状态 ──────────────────────────────────────────────────
async function refreshStatus() {
  const resp = await sendBg({ action: 'get-status' });
  if (!resp) return;

  if (resp.recording) {
    switchView('recording');
    updateRecCount(resp.steps.length);
    if (resp.startTime) startTimer(resp.startTime);
  } else if (resp.steps.length > 0) {
    await showStepsView(resp.steps, resp.title);
    if (resp.startTime) {
      timerEl.textContent = formatDuration(resp.startTime, Date.now());
    }
  } else {
    switchView('idle');
  }
}

// ── 渲染步骤列表 ──────────────────────────────────────────────
async function showStepsView(steps, title) {
  switchView('steps');
  stepsTitle.textContent = title || '录制结果';
  stepsCount.textContent = `${steps.length} 步`;

  if (steps.length === 0) {
    emptyState.classList.remove('hidden');
    stepsList.classList.add('hidden');
    viewExport.classList.add('hidden');
    return;
  }

  emptyState.classList.add('hidden');
  stepsList.classList.remove('hidden');
  viewExport.classList.remove('hidden');

  stepsList.innerHTML = '';
  steps.forEach((step) => {
    const card = document.createElement('div');
    card.className = 'step-card';
    card.innerHTML = `
      <img class="step-thumb" src="${step.screenshot}" alt="步骤 ${step.number}" />
      <div class="step-info">
        <div class="step-number">步骤 ${step.number}</div>
        <div class="step-desc">${escapeHtml(step.action.description)}</div>
        <div class="step-time">${formatTime(step.timestamp)}</div>
      </div>
      <button class="step-delete" data-id="${step.id}" title="删除此步骤">×</button>
    `;
    stepsList.appendChild(card);
  });

  stepsList.querySelectorAll('.step-delete').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.currentTarget.dataset.id;
      await sendBg({ action: 'delete-step', stepId: id });
      await refreshStatus();
    });
  });
}

// ══════════════════════════════════════════════════════════════
//  PPT 导出（通过 Background 中继到 Offscreen Document）
// ══════════════════════════════════════════════════════════════

async function exportPPT() {
  exportOverlay.classList.remove('hidden');
  exportStatus.textContent = '正在准备数据…';

  try {
    // 1. 从 background 获取步骤数据
    const resp = await sendBg({ action: 'export-ppt' });
    if (!resp?.success) {
      alert(resp?.reason === 'no-steps' ? '没有步骤可导出，请先录制。' : '导出失败');
      exportOverlay.classList.add('hidden');
      return;
    }

    const { title, steps } = resp.data;

    // 2. 通过 Background 中继，让 Offscreen Document 生成 PPT
    exportStatus.textContent = `正在生成 PPT（${steps.length} 页）…`;

    const genResp = await sendBg({
      action: 'generate-ppt',
      data: { title, steps },
    });

    if (!genResp?.success) {
      alert('PPT 生成失败: ' + (genResp?.error || '未知错误'));
      exportOverlay.classList.add('hidden');
      return;
    }

    // 3. 将 base64 转回 Blob 并下载
    exportStatus.textContent = '正在保存文件…';

    const binaryStr = atob(genResp.data);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    const blob = new Blob([bytes], {
      type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    });

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const safeName = title.replace(/[\\/:*?"<>|]/g, '_');
      chrome.downloads.download({
        url: dataUrl,
        filename: `${safeName}.pptx`,
        saveAs: true,
      }, () => {
        exportOverlay.classList.add('hidden');
        if (chrome.runtime.lastError) {
          console.error('Download error:', chrome.runtime.lastError);
        }
      });
    };
    reader.readAsDataURL(blob);

  } catch (err) {
    console.error('Export failed:', err);
    alert('导出失败: ' + err.message);
    exportOverlay.classList.add('hidden');
  }
}

// ── 计时器 ────────────────────────────────────────────────────
function startTimer(startTime) {
  stopTimer();
  const start = startTime || Date.now();
  timerInterval = setInterval(() => {
    timerEl.textContent = formatDuration(start, Date.now());
  }, 1000);
}

function stopTimer() {
  if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
}

function updateRecCount(count) {
  recCount.textContent = `${count} 步`;
}

function formatDuration(from, to) {
  const sec = Math.floor((to - from) / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function formatTime(ts) {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
}

// ── 工具函数 ──────────────────────────────────────────────────
function sendBg(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (resp) => {
      if (chrome.runtime.lastError) { resolve(null); return; }
      resolve(resp);
    });
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
