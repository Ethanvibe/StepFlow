/* ============================================================
   yipengPPT  –  Background Service Worker (Manifest V3)
   ─ 录制状态管理（带 keepalive 防杀 + 持久化）
   ─ 截图捕获 & 步骤存储
   ─ PPT 导出中继（popup ↔ offscreen）
   ============================================================ */

// ── 录制状态 ──────────────────────────────────────────────────
let state = {
  recording: false,
  steps: [],
  title: '',
  startTime: null,
  tabId: null,
};

let screenshotTimer = null;
let stateRestored = false;

// ── 启动时从 session storage 恢复关键状态 ─────────────────────
(async () => {
  try {
    const saved = await chrome.storage.session.get(['recording', 'title', 'startTime']);
    if (saved.recording) {
      state.recording = true;
      state.title     = saved.title     || '未命名流程';
      state.startTime = saved.startTime || Date.now();
      // steps 因体积太大未持久化，重启后清空
      state.steps = [];
      chrome.action.setBadgeText({ text: '0' });
      chrome.action.setBadgeBackgroundColor({ color: '#EF4444' });
      chrome.action.setBadgeTextColor({ color: '#FFFFFF' });
    }
  } catch (_) {}
  stateRestored = true;
})();

// 设置 session 可从 content script 访问
try { chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' }); } catch (_) {}

// ── 消息路由 ──────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handlers = {
    // ── Popup 命令 ──
    'start-recording':    handleStartRecording,
    'stop-recording':     handleStopRecording,
    'get-status':         handleGetStatus,
    'delete-step':        handleDeleteStep,
    'clear-steps':        handleClearSteps,
    'export-ppt':         handleExportPPT,
    'create-offscreen':   handleCreateOffscreen,
    // ── Content Script ──
    'capture-action':     handleCaptureAction,
    'ping':               handlePing,
    // ── PPT 中继（popup → background → offscreen）──
    'generate-ppt':       handleGeneratePPT,
  };
  const fn = handlers[msg.action || msg.type];
  if (fn) { fn(msg, sender, sendResponse); return true; }
  // 未识别的消息 — 不返回 true，让其他监听器（offscreen）有机会处理
});

// ── Keepalive ─────────────────────────────────────────────────
function handlePing(_m, _s, sendResponse) {
  sendResponse({ alive: true });
}

// ── Popup: 开始录制 ──────────────────────────────────────────
async function handleStartRecording(msg, _sender, sendResponse) {
  if (state.recording) { sendResponse({ success: false, reason: 'already-recording' }); return; }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { sendResponse({ success: false, reason: 'no-tab' }); return; }

  state.recording = true;
  state.steps     = [];
  state.title     = msg.title || '未命名流程';
  state.startTime = Date.now();
  state.tabId     = tab.id;

  // 持久化关键标志
  await chrome.storage.session.set({
    recording: true,
    title: state.title,
    startTime: state.startTime,
  });

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });
  } catch (_) {}

  chrome.action.setBadgeText({ text: '0' });
  chrome.action.setBadgeBackgroundColor({ color: '#EF4444' });
  chrome.action.setBadgeTextColor({ color: '#FFFFFF' });

  sendResponse({ success: true });
}

// ── Popup: 停止录制 ──────────────────────────────────────────
function handleStopRecording(_msg, _sender, sendResponse) {
  state.recording = false;
  chrome.action.setBadgeText({ text: '' });
  chrome.storage.session.remove(['recording', 'title', 'startTime']);
  if (screenshotTimer) { clearTimeout(screenshotTimer); screenshotTimer = null; }
  sendResponse({ success: true, steps: state.steps });
}

// ── Popup: 获取状态 ──────────────────────────────────────────
function handleGetStatus(_msg, _sender, sendResponse) {
  sendResponse({
    recording: state.recording,
    steps:     state.steps,
    title:     state.title,
    startTime: state.startTime,
  });
}

// ── Popup: 删除步骤 ──────────────────────────────────────────
function handleDeleteStep(msg, _sender, sendResponse) {
  state.steps = state.steps.filter(s => s.id !== msg.stepId);
  chrome.action.setBadgeText({ text: String(state.steps.length) });
  sendResponse({ success: true });
}

// ── Popup: 清空步骤 ──────────────────────────────────────────
function handleClearSteps(_msg, _sender, sendResponse) {
  state.steps = [];
  chrome.action.setBadgeText({ text: state.recording ? '0' : '' });
  sendResponse({ success: true });
}

// ── Popup: 获取导出数据 ──────────────────────────────────────
function handleExportPPT(_msg, _sender, sendResponse) {
  if (state.steps.length === 0) {
    sendResponse({ success: false, reason: 'no-steps' });
    return;
  }
  sendResponse({
    success: true,
    data: {
      title:     state.title,
      steps:     state.steps,
      startTime: state.startTime,
    },
  });
}

// ── Content Script: 截图 & 记录步骤 ──────────────────────────
function handleCaptureAction(msg, sender, sendResponse) {
  if (!state.recording) { sendResponse({ ok: false }); return; }

  const tabId = sender.tab?.id;
  if (!tabId) { sendResponse({ ok: false }); return; }
  state.tabId = tabId;

  if (screenshotTimer) clearTimeout(screenshotTimer);

  screenshotTimer = setTimeout(async () => {
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });

      const step = {
        id:            Date.now() + '-' + Math.random().toString(36).slice(2, 6),
        number:        state.steps.length + 1,
        action:        msg.actionData,
        screenshot:    dataUrl,
        timestamp:     Date.now(),
        url:           sender.tab?.url || '',
        pageTitle:     sender.tab?.title || '',
        viewportWidth: sender.tab?.width || 1920,
        viewportHeight: sender.tab?.height || 1080,
      };

      state.steps.push(step);
      chrome.action.setBadgeText({ text: String(state.steps.length) });

      try {
        await chrome.runtime.sendMessage({ action: 'step-updated', step });
      } catch (_) {}

    } catch (err) {
      console.error('[yipengPPT] screenshot failed:', err);
    }
    screenshotTimer = null;
  }, 500);  // 500ms 延迟：红色圆圈已显示，页面 UI 也已更新

  sendResponse({ ok: true });
}

// ══════════════════════════════════════════════════════════════
//  Offscreen Document 管理 & PPT 中继
// ══════════════════════════════════════════════════════════════

async function handleCreateOffscreen(_msg, _sender, sendResponse) {
  try {
    const existing = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
    });
    if (existing.length > 0) {
      sendResponse({ success: true, existed: true });
      return;
    }

    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['WORKERS'],
      justification: 'PPT generation using PptxGenJS library',
    });

    // 等待 offscreen 页面 + PptxGenJS 加载完成
    await new Promise(r => setTimeout(r, 800));
    sendResponse({ success: true, existed: false });
  } catch (err) {
    console.error('[yipengPPT] offscreen create failed:', err);
    sendResponse({ success: false, error: err.message });
  }
}

/**
 * PPT 中继：popup 发消息给 background，background 转发给 offscreen，
 * 等 offscreen 回传结果后再回传给 popup。
 * 这样避免了 popup 直接和 offscreen 通信时的消息路由冲突。
 */
async function handleGeneratePPT(msg, _sender, sendResponse) {
  try {
    // 确保 offscreen 已创建
    const existing = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
    });
    if (existing.length === 0) {
      await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['WORKERS'],
        justification: 'PPT generation',
      });
      await new Promise(r => setTimeout(r, 1000));
    }

    // 转发给 offscreen
    const result = await chrome.runtime.sendMessage({
      type: 'generate-ppt-offscreen',
      data: msg.data,
    });

    sendResponse(result);
  } catch (err) {
    console.error('[yipengPPT] PPT relay error:', err);
    sendResponse({ success: false, error: err.message });
  }
}
