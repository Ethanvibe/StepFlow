/* ============================================================
   yipengPPT  –  Offscreen Document Script (PPT 生成)
   ============================================================ */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'generate-ppt-offscreen') return false;

  const { title, steps } = msg.data;
  console.log('[yipengPPT] Received PPT request:', title, steps.length, 'steps');

  buildPPT(title, steps)
    .then((base64) => {
      console.log('[yipengPPT] PPT generated, base64 length:', base64.length);
      sendResponse({ success: true, data: base64 });
    })
    .catch((err) => {
      console.error('[yipengPPT] PPT error:', err);
      sendResponse({ success: false, error: err.message });
    });

  return true;
});

async function buildPPT(title, steps) {
  const PptxGenJSCtor = window.PptxGenJS;
  if (!PptxGenJSCtor) throw new Error('PptxGenJS 库未加载');

  const pptx = new PptxGenJSCtor();
  pptx.author = 'yipengPPT';
  pptx.title  = title;
  pptx.layout = 'LAYOUT_16x9';  // 10" × 5.625"

  const SW = 10, SH = 5.625;

  // ═══════ 1. 封面 ═══════
  const cover = pptx.addSlide();
  cover.background = { fill: 'F8FAFC' };
  cover.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: SW, h: 0.06, fill: { color: '6366F1' } });

  cover.addText(title, {
    x: 0.8, y: 1.8, w: 8.4, h: 1.2,
    fontSize: 32, fontFace: 'Microsoft YaHei',
    color: '1E293B', bold: true,
  });
  cover.addText(`共 ${steps.length} 个步骤  ·  ${new Date().toLocaleDateString('zh-CN')}`, {
    x: 0.8, y: 3.1, w: 8.4, h: 0.5,
    fontSize: 14, fontFace: 'Microsoft YaHei', color: '64748B',
  });
  cover.addText('由 yipengPPT 自动生成', {
    x: 0.8, y: 4.5, w: 8.4, h: 0.4,
    fontSize: 11, fontFace: 'Microsoft YaHei', color: '94A3B8',
  });

  // ═══════ 2. 步骤页 ═══════
  for (let i = 0; i < steps.length; i++) {
    const step  = steps[i];
    const slide = pptx.addSlide();
    slide.background = { fill: 'FFFFFF' };

    // 极简顶栏：装饰条 + 步骤号
    slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: SW, h: 0.035, fill: { color: '6366F1' } });
    slide.addText(`步骤 ${i + 1}`, {
      x: 0.3, y: 0.06, w: 2.0, h: 0.32,
      fontSize: 11, fontFace: 'Microsoft YaHei',
      color: '6366F1', bold: true, valign: 'middle',
    });

    // ── 截图：尽可能大 ──
    const MAX_W = 9.4;
    const MAX_H = 4.8;      // 用满垂直空间
    const IMG_X = (SW - MAX_W) / 2;  // 居中
    const IMG_Y = 0.45;

    const vw = step.viewportWidth  || 1920;
    const vh = step.viewportHeight || 1080;
    const ar = vw / vh;

    let imgW, imgH;
    if (ar >= MAX_W / MAX_H) {
      imgW = MAX_W;
      imgH = MAX_W / ar;
    } else {
      imgH = MAX_H;
      imgW = MAX_H * ar;
    }
    const offX = IMG_X + (MAX_W - imgW) / 2;

    if (step.screenshot && step.screenshot.length > 100) {
      try {
        slide.addImage({
          data: step.screenshot,
          x: offX, y: IMG_Y, w: imgW, h: imgH,
          shadow: { type: 'outer', blur: 4, offset: 1, color: '000000', opacity: 0.10 },
        });
      } catch (_) {
        slide.addShape(pptx.ShapeType.rect, {
          x: IMG_X, y: IMG_Y, w: MAX_W, h: MAX_H,
          fill: { color: 'F1F5F9' }, rectRadius: 0.05,
        });
        slide.addText('[截图加载失败]', {
          x: IMG_X, y: IMG_Y, w: MAX_W, h: MAX_H,
          fontSize: 13, color: '94A3B8', align: 'center', valign: 'middle',
        });
      }
    } else {
      slide.addShape(pptx.ShapeType.rect, {
        x: IMG_X, y: IMG_Y, w: MAX_W, h: MAX_H,
        fill: { color: 'F1F5F9' }, rectRadius: 0.05,
      });
      slide.addText('[无截图]', {
        x: IMG_X, y: IMG_Y, w: MAX_W, h: MAX_H,
        fontSize: 13, color: '94A3B8', align: 'center', valign: 'middle',
      });
    }

    // ── 描述文字（小字，底部一行） ──
    const descY = IMG_Y + Math.min(imgH, MAX_H) + 0.05;
    slide.addText(step.action?.description || '', {
      x: 0.3, y: descY, w: 9.4, h: 0.28,
      fontSize: 9, fontFace: 'Microsoft YaHei',
      color: '64748B', valign: 'middle',
    });
  }

  // ═══════ 3. 结尾页 ═══════
  const ending = pptx.addSlide();
  ending.background = { fill: 'F8FAFC' };
  ending.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: SW, h: 0.06, fill: { color: '6366F1' } });

  ending.addText('完成', {
    x: 0.8, y: 2.0, w: 8.4, h: 1.0,
    fontSize: 36, fontFace: 'Microsoft YaHei',
    color: '1E293B', bold: true, align: 'center',
  });
  ending.addText(`本教程共 ${steps.length} 个步骤`, {
    x: 0.8, y: 3.1, w: 8.4, h: 0.5,
    fontSize: 14, fontFace: 'Microsoft YaHei', color: '64748B', align: 'center',
  });
  ending.addText('由 yipengPPT 自动生成', {
    x: 0.8, y: 4.0, w: 8.4, h: 0.4,
    fontSize: 11, fontFace: 'Microsoft YaHei', color: '94A3B8', align: 'center',
  });

  const buf = await pptx.write({ outputType: 'arraybuffer' });
  return arrayBufferToBase64(buf);
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunk = 8192;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}
