/* ============================================================
   yipengPPT  –  Content Script
   注入到页面中，捕获用户的点击 / 输入等操作，
   将操作信息发送给 Background Service Worker 截图存档。
   ============================================================ */

(() => {
  if (window.__stepFlowInjected) return;
  window.__stepFlowInjected = true;

  // ── 状态 ──────────────────────────────────────────────────
  const lastInputValues = new WeakMap();  // 追踪每个输入元素的值
  let keepaliveTimer = null;

  // ── Service Worker 保活：每 20 秒 ping 一次 ────────────────
  function startKeepalive() {
    if (keepaliveTimer) return;
    const ping = () => {
      chrome.runtime.sendMessage({ action: 'ping' }, () => {
        if (chrome.runtime.lastError) {}
      });
    };
    ping();
    keepaliveTimer = setInterval(ping, 20000);
  }
  startKeepalive();

  // ══════════════════════════════════════════════════════════
  //  事件监听
  // ══════════════════════════════════════════════════════════

  // ── 1. 点击（capture 阶段） ──────────────────────────────
  document.addEventListener('click', (e) => {
    if (e.target.closest('#yipengppt-toast')) return;
    if (e.target.closest('#yipengppt-circle')) return;
    sendAction(e.target, 'click', e);
  }, true);

  // ── 2. 文本输入（focusout 时记录最终值） ─────────────────
  document.addEventListener('focusout', (e) => {
    const el = e.target;
    if (!el || !el.tagName) return;
    const tag  = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();

    if (tag === 'input' && type === 'password') return;
    if (tag === 'input' || tag === 'textarea') {
      const val = el.value || '';
      const lastVal = lastInputValues.get(el);
      // 记录每一次变化（包括首次获焦后直接离开）
      if (val !== lastVal || val.length > 0) {
        lastInputValues.set(el, val);
        sendAction(el, 'type');
      }
    }
  }, true);

  // ── 3. 下拉框 & 复选框 & 单选框 ─────────────────────────
  document.addEventListener('change', (e) => {
    const el  = e.target;
    const tag = el?.tagName?.toLowerCase();
    if (tag === 'select') {
      sendAction(el, 'select');
    } else if (tag === 'input') {
      const type = (el.getAttribute('type') || '').toLowerCase();
      if (type === 'checkbox' || type === 'radio') {
        sendAction(el, 'check');
      }
    }
  }, true);

  // ══════════════════════════════════════════════════════════
  //  核心：发送操作 → Background（无节流）
  // ══════════════════════════════════════════════════════════

  function sendAction(element, actionType, mouseEvent) {
    const label     = getElementLabel(element);
    const elType    = classifyElement(element);
    const selector  = buildSelector(element);

    const actionData = {
      type:        actionType,
      elType,
      label,
      selector,
      description: buildDescription(actionType, elType, label),
    };

    // 发送给 background，仅在确认录制中时才画圈 + toast
    chrome.runtime.sendMessage({ action: 'capture-action', actionData }, (resp) => {
      if (chrome.runtime.lastError) return;
      if (!resp?.ok) return;  // 未录制 → 什么都不做

      // 录制中 → 画红色圆圈（background 500ms 后截图，圆圈会出现在截图中）
      if (mouseEvent && actionType === 'click') {
        showRedCircle(mouseEvent.clientX, mouseEvent.clientY);
      } else {
        const rect = element.getBoundingClientRect();
        showRedCircle(rect.left + rect.width / 2, rect.top + rect.height / 2);
      }
      showToast('✓ 已记录');
    });
  }

  // ══════════════════════════════════════════════════════════
  //  红色半透明圆圈标记
  // ══════════════════════════════════════════════════════════

  function showRedCircle(x, y) {

    const circle = document.createElement('div');
    circle.id = 'yipengppt-circle-' + Date.now();

    const size = 44;

    Object.assign(circle.style, {
      position:      'fixed',
      left:          (x - size / 2) + 'px',
      top:           (y - size / 2) + 'px',
      width:         size + 'px',
      height:        size + 'px',
      borderRadius:  '50%',
      backgroundColor: 'rgba(239, 68, 68, 0.35)',
      border:        '3px solid rgba(220, 38, 38, 0.8)',
      zIndex:        '2147483646',
      pointerEvents: 'none',
      transition:    'opacity 0.4s ease',
      opacity:       '1',
    });

    // 外圈扩散动画
    const ring = document.createElement('div');
    Object.assign(ring.style, {
      position:      'absolute',
      inset:         '-6px',
      borderRadius:  '50%',
      border:        '2px solid rgba(239, 68, 68, 0.4)',
      animation:     'yipengppt-ring 0.6s ease-out',
    });
    circle.appendChild(ring);

    // 注入动画关键样式（只注入一次）
    if (!document.getElementById('yipengppt-keyframes')) {
      const style = document.createElement('style');
      style.id = 'yipengppt-keyframes';
      style.textContent = `
        @keyframes yipengppt-ring {
          0%   { transform: scale(0.8); opacity: 1; }
          100% { transform: scale(1.6); opacity: 0; }
        }
      `;
      document.head.appendChild(style);
    }

    document.body.appendChild(circle);

    // 2 秒后淡出（截图在 500ms 时已完成，圆圈一定在截图中）
    setTimeout(() => { circle.style.opacity = '0'; }, 2000);
    setTimeout(() => { circle.remove(); }, 2400);
  }

  // ══════════════════════════════════════════════════════════
  //  元素分析工具
  // ══════════════════════════════════════════════════════════

  function classifyElement(el) {
    const tag  = el.tagName.toLowerCase();
    const role = el.getAttribute('role') || '';
    const type = (el.getAttribute('type') || '').toLowerCase();

    if (tag === 'button' || role === 'button')                          return 'button';
    if (tag === 'a')                                                    return 'link';
    if (tag === 'input' && ['text','email','search','tel','url','number','password'].includes(type)) return 'text-field';
    if (tag === 'input' && type === 'checkbox')                         return 'checkbox';
    if (tag === 'input' && type === 'radio')                            return 'radio';
    if (tag === 'textarea')                                             return 'textarea';
    if (tag === 'select')                                               return 'dropdown';
    if (tag === 'img')                                                  return 'image';
    if (tag === 'label')                                                return 'label';
    if (role === 'tab' || role === 'menuitem')                          return 'tab';
    return 'element';
  }

  function getElementLabel(el) {
    let label = el.getAttribute('aria-label')
             || el.textContent?.trim()
             || el.getAttribute('placeholder')
             || el.getAttribute('title')
             || el.getAttribute('name')
             || '';
    label = label.replace(/\s+/g, ' ').substring(0, 60);

    if (!label) {
      const tag = el.tagName.toLowerCase();
      const id  = el.id ? `#${el.id}` : '';
      label = `<${tag}${id}>`;
    }
    return label;
  }

  function buildDescription(actionType, elType, label) {
    const map = {
      'click': {
        'button':     `点击了按钮「${label}」`,
        'link':       `点击了链接「${label}」`,
        'tab':        `点击了标签「${label}」`,
        'image':      `点击了图片`,
        'checkbox':   `点击了复选框「${label}」`,
        'radio':      `选择了单选项「${label}」`,
        'dropdown':   `点击了下拉框「${label}」`,
        'text-field': `点击了输入框「${label}」`,
        'textarea':   `点击了文本区域「${label}」`,
        'label':      `点击了标签「${label}」`,
        'element':    `点击了页面元素「${label}」`,
      },
      'type': {
        'text-field': `在输入框「${label}」中输入了内容`,
        'textarea':   `在文本区域「${label}」中输入了内容`,
        'element':    `在「${label}」中输入了内容`,
      },
      'select': {
        'dropdown':   `在下拉框「${label}」中选择了选项`,
        'element':    `在「${label}」中选择了选项`,
      },
      'check': {
        'checkbox':   `切换了复选框「${label}」`,
        'radio':      `选择了单选项「${label}」`,
        'element':    `切换了「${label}」`,
      },
    };
    return map[actionType]?.[elType]
        || map[actionType]?.['element']
        || `在「${label}」上执行了 ${actionType} 操作`;
  }

  function buildSelector(el) {
    if (el.id) return `#${el.id}`;

    const tag = el.tagName.toLowerCase();
    const parts = [tag];

    if (el.className && typeof el.className === 'string') {
      const cls = el.className.trim().split(/\s+/).slice(0, 2).join('.');
      if (cls) parts.push('.' + cls);
    }

    const name = el.getAttribute('name');
    if (name) parts.push(`[name="${name}"]`);

    let sel = parts.join('');
    try {
      if (document.querySelectorAll(sel).length !== 1) {
        sel = buildPathSelector(el);
      }
    } catch (_) {
      sel = buildPathSelector(el);
    }
    return sel;
  }

  function buildPathSelector(el) {
    const path = [];
    let node = el;
    while (node && node !== document.body && node !== document.documentElement) {
      let seg = node.tagName.toLowerCase();
      if (node.id) { path.unshift(`#${node.id}`); break; }
      if (node.parentElement) {
        const siblings = Array.from(node.parentElement.children).filter(n => n.tagName === node.tagName);
        if (siblings.length > 1) {
          const idx = siblings.indexOf(node) + 1;
          seg += `:nth-of-type(${idx})`;
        }
      }
      path.unshift(seg);
      node = node.parentElement;
    }
    return path.join(' > ');
  }

  // ── Toast 提示 ────────────────────────────────────────────
  let toastTimer = null;
  function showToast(text) {
    let toast = document.getElementById('yipengppt-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'yipengppt-toast';
      Object.assign(toast.style, {
        position: 'fixed',
        bottom:   '24px',
        right:    '24px',
        padding:  '8px 16px',
        background: '#1E1E2E',
        color:    '#A5F3FC',
        fontSize: '13px',
        fontFamily: 'system-ui, sans-serif',
        borderRadius: '8px',
        zIndex:   '2147483647',
        opacity:  '0',
        transition: 'opacity 0.25s ease',
        pointerEvents: 'none',
        boxShadow: '0 2px 12px rgba(0,0,0,0.25)',
      });
      document.body.appendChild(toast);
    }
    toast.textContent = text;
    toast.style.opacity = '1';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.style.opacity = '0'; }, 1200);
  }

})();
